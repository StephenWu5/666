Page({
  data: {
    
  },
  onLoad: function () {
   
  },
  getCalendarData(e) { // 监听日历数据
    console.log(e.detail)
  }
 
})