// pages/subPack/otherAnimation/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {


  },

  
  onLoad: function (options) {

  },

 
  onShow: function () {

  },

})