
const QQMapWX = require('./qqmap-lib/qqmap-wx-jssdk.js');

const qqMapSdk = new QQMapWX({
    key: 'CREBZ-B7PKX-GL44O-7ITDB-7UFU7-OLFDV'
});


module.exports = qqMapSdk
