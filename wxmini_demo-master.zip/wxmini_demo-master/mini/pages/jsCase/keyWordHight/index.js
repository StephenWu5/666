// pages/jsCase/keyWordHight/index.js
Page({
  data: {
    list: [
      '苏苏小苏苏',
      '测试1',
      '测试2',
      '测试苏苏苏',
    ]
  },
  onLoad: function () {
  }
})
