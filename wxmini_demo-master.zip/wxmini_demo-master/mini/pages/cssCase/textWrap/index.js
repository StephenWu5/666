// pages/cssCase/textWrap/index.js
Page({
  data: {
    content: [
      '苏苏_icon',
      '不要图片？CSS实现大屏常见不规则边框（系列二），速速来Get吧~',
      '定义css变量，--w宽度，--h高度，--line-bg渐变边框色，--content-bg内容背景色 ， --pathclip-path裁剪形状',
      '添加子元素，设置宽高为w和h，父元素随着子元素大小拉伸，设置resize进行拉伸，并设置最小宽度最大宽度,给box设置伪元素，设置内容背景色，设置z-index为-1，不遮挡内容文字'
    ]
  },
})