// pages/another/customScroll/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[
      {
        name:'回家的诱惑',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'鱿鱼游戏',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'主君的太阳',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'地陷',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'寄生虫',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'紧急救援',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
      {
        name:'逆行者',
        price:'888',
        sell_price:'9.9',
        star_date:'2021.10.1',
        end_date:'2021.10.8'
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
})