// pages/another/imgRadius/index.js
Page({


  data: {

  },

 
})