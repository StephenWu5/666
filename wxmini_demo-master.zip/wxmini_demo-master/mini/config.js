//接口地址
// //  const baseUrl = 'https://aa-bb.cn'; //开发地址
// const baseUrl = 'https://aa-bb.cn'; //测试地址
// // const baseUrl = 'https://aa-bb.cn';//正式站地址

// //测试图片地址
// const imageUrl = 'https://aa-bb.cn';
// //正式站图片地址
// // const imageUrl = 'https://aa-bb.cn';

// export {
//   baseUrl,
//   imageUrl
// }

export default {
  host:'https://aa-bb.cn'
}